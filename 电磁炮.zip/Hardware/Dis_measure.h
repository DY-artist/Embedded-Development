#ifndef DIS_MEASURE_H__
#define DIS_MEASURE_H__

//���������   US-015
void DisMeasure_Init(void);
static void OpenTimerForHc(void);
static void CloseTimerForHc(void);
void TIM2_IRQHandler(void);
u32 GetEchoTimer(void);
float Hcsr04GetLength(void);

#endif

