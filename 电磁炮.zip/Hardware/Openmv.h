#ifndef __OPENMV_H__
#define __OPENMV_H__

void Openmv_Init(void);
void Openmv_SendByte(uint8_t Byte);
uint8_t Openmv_GetRxFlag(void);
uint8_t Openmv_GetRxData(void);

#endif
